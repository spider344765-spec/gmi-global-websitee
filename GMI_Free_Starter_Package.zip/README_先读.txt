GMI 免费起步套装（网站模板 + 香港公司筹备资料）
=================================================

重要说明
- 本套装为筹备模板，不代表 GLOBAL MERIDIAN INTERNATIONAL TRADING LIMITED 已成立。
- 网站目前为静态网站，未连接后台数据库、客户表单、支付系统或企业邮箱。
- globalmeridian.com 尚未确认可注册，也未购买或保留。
- 不要在正式上线前把拟用公司名称、建议邮箱或目标市场描述为已获批准/已实际开展业务。
- 免费指的是本套装文件和基础静态网站方案可免费使用；公司注册政府费用、域名、商业邮箱、付费托管、专业法律/会计服务可能收费。

网站预览
1. 打开 website/index.html。
2. 网站支持简体中文、繁体中文、英文自动按浏览器语言选择，也可手动切换。
3. 可免费部署到支持静态网站的免费层平台（例如 GitHub Pages、Cloudflare Pages）；平台条款和免费额度可能变化。
4. 使用自有域名通常需付费。也可先使用平台提供的免费子域名。

上线前必改
- 公司正式法定名称、CI/BR资料、注册地址、真实电话及电邮。
- 真实经营商品、服务、市场及贸易合规说明。
- 隐私政策、Cookie说明（如适用）、网站使用条款。
- 删除或更正任何不真实或尚未落实的业务陈述。
- 配置HTTPS、备份、网站访问权限及安全更新。

域名
- 目标域名：globalmeridian.com
- 当前状态：未获权威实时确认；不得视为已注册/已预留。
- 公司成立后，建议将注册人（Registrant）登记为公司法定名称。
- 注册时启用双重验证、自动续费、域名锁定，并使用公司控制的邮箱。
- 官方核查：https://lookup.icann.org/
- Verisign RDAP：https://rdap.verisign.com/com/v1/domain/globalmeridian.com

香港公司筹备
- 公司名称查册与注册：香港公司注册处 https://www.cr.gov.hk/
- 香港税务局商业登记：https://www.ird.gov.hk/
- 香港知识产权署商标资料：https://www.ipd.gov.hk/
- 本套装不是法律意见或公司注册申请；请按注册处最新规定及专业意见办理。

文件说明
- templates/GMI_Company_Setup_Worksheet.docx：公司注册资料收集工作表。
- templates/Shareholders_Directors_Register.csv：股东/董事资料草表。
- templates/Trading_Document_Checklist.csv：贸易单证清单。
- templates/Business_Contacts.csv：客户及供应商联络资料模板。
- templates/README_资料填写说明.txt：资料保护及填写提示。
